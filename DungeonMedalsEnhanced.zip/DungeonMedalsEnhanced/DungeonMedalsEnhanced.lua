--DungeonMedalsEnhanced uploaded by GreenyNeko on Curse, reworked/updated by Tavikins
 
require "Apollo"
require "Sound"
require "GameLib"
require "PublicEvent"

local debugmode = true
local DungeonMedalsEnhanced = {}

local kstrNoMedal		= "Protogames:spr_Protogames_Icon_MedalFailed"
local kstrBronzeMedal	= "Protogames:spr_Protogames_Icon_MedalBronze"
local kstrSilverMedal	= "Protogames:spr_Protogames_Icon_MedalSilver"
local kstrGoldMedal		= "Protogames:spr_Protogames_Icon_MedalGold"

local ktDungeonTimerIds = {
	["The Birth of a Corrupted God"] = 3201,
	["Forging an Armageddon"] = 3202,
	["No Merrier Place Than Hell"] = 3203,
	["The Sanctuary Defiled"] = 3204,
	["Ultimate Protogames"] = 0,
	["Protogames Academy"] = 0,
}

local ktDungeonTimers = {
	["The Birth of a Corrupted God"] = 40 * 60,
	["Forging an Armageddon"] = 40 * 60,
	["No Merrier Place Than Hell"] = 45 * 60,
	["The Sanctuary Defiled"] = 60 * 60,
	["Ultimate Protogames"] = 0,
	["Protogames Academy"] = 0,
}

function DungeonMedalsEnhanced:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end

function DungeonMedalsEnhanced:Init()
	Apollo.RegisterAddon(self)
end

function DungeonMedalsEnhanced:OnLoad()
	self.xmlDoc = XmlDoc.CreateFromFile("DungeonMedalsEnhanced.xml")
	self.xmlDoc:RegisterCallback("OnDocumentReady", self)
	
	self:InitializeVars()
end

function DungeonMedalsEnhanced:InitializeVars()
	self.nTimeElapsed = 0
	self.nPointDelta = 0
	self.nPoints	= 0
	self.nExpectedPoints = 0
	self.nBronze = 0
	self.nSilver = 0
	self.nGold = 0
	self.bMatchStarted = false
	self.tObjectives = {}
	self.peMatch = nil
	self.dungeon = nil
	self.debugtotal = 0
end

function DungeonMedalsEnhanced:OnDocumentReady()
	if not self.xmlDoc then
		return
	end
	
	Apollo.RegisterEventHandler("ChangeWorld", 				"Reset", self)
	Apollo.RegisterEventHandler("PublicEventStart",			"CheckForDungeon", self)
	Apollo.RegisterEventHandler("MatchEntered", 			"CheckForDungeon", self)
	Apollo.RegisterEventHandler("PublicEventStatsUpdate", 	"OnPublicEventStatsUpdate", self)
	
	Apollo.RegisterSlashCommand("dme",						"OnSlashCommand", self)
	
	self.timerMatchOneSec = ApolloTimer.Create(1.0, true, "OnOneSecTimer", self)
	self.timerPointsCleanup = ApolloTimer.Create(1.5, true, "OnPointsCleanUpTimer", self)
	
	self.wndMain = Apollo.LoadForm(self.xmlDoc, "DungeonMedalsMain", "FixedHudStratum", self)
	self.wndDebug = Apollo.LoadForm(self.xmlDoc, "debugwindow", nil, self)
	self.wndList = self.wndDebug:FindChild("list")
	
	if not self:CheckForDungeon() then
		self:Reset()
	else
		self.timerMatchOneSec:Start()
		self:UpdateDebug()
		self:UpdatePoints()
	end
end

function DungeonMedalsEnhanced:Reset()
	self.wndMain:Show(false)
	self.wndDebug:Show(false)
	self.timerMatchOneSec:Stop()
	self.timerPointsCleanup:Stop()
	
	self:InitializeVars()
end

--Originally this window was supposed to be for debugging,
--but was shown to be super useful, names remained the same,
--because lazy.

function DungeonMedalsEnhanced:UpdateDebug()
	if not self.peMatch then return end
	local objpoints
	local objtext
	local objstatus
	self.debugtotal = self.debugtotal or 0
	
	for i, v in ipairs(self.wndList:GetChildren()) do
		v:Destroy()
	end
	
	self.debugtotal = 0
	
	for i, v in ipairs(self.peMatch:GetObjectives()) do
		objpoints = v:GetMedalPoints() or -1
		objtext = v:GetDescription() or ""
		objstatus = v:GetStatus() or -1
		if objstatus == 1 then
			local wndCurrent = Apollo.LoadForm(self.xmlDoc, "debugline", self.wndList, self)
			wndCurrent:FindChild("points"):SetText(objpoints)
			wndCurrent:FindChild("status"):SetText(objstatus)
			wndCurrent:FindChild("text"):SetText(objtext)
			self.debugtotal = self.debugtotal + objpoints
		end
	end
	self.wndList:ArrangeChildrenVert(Window.CodeEnumArrangeOrigin.LeftOrTop)
	self.wndDebug:FindChild("total"):SetText(self.debugtotal)
end


function DungeonMedalsEnhanced:OnPublicEventStatsUpdate(peUpdated)
	if peUpdated:GetEventType() ~= PublicEvent.PublicEventType_Dungeon then
		return
	end
	local nCurrentPoints = peUpdated:GetStat(PublicEvent.PublicEventStatType.MedalPoints)
	if self.nPoints == nCurrentPoints then
		return
	end	
	
	self.timerPointsCleanup:Stop()
	self.timerPointsCleanup:Start()
	
	self.nPointDelta = self.nPointDelta + nCurrentPoints - self.nPoints

	if not self.wndPoints then
		self.wndPoints = Apollo.LoadForm(self.xmlDoc, "DungeonMedalsPlusPoints", "FixedHudStratumLow", self)
	end
	
	Print("You received " .. (self.nPointDelta or 0) .. " points.")
	self.wndPoints:SetData(self.nPointDelta)
	self.wndPoints:SetText("+"..tostring(Apollo.FormatNumber(self.nPointDelta, 0, true)))
	self.wndPoints:Show(true, false, 1.0)
	
	self:UpdateDebug()
	self:UpdatePoints()
end

function DungeonMedalsEnhanced:UpdatePoints()
	if self.peMatch then
		self.nPoints			= self.peMatch:GetStat(PublicEvent.PublicEventStatType.MedalPoints)	or self.nPoints or 0

		local bonus = 0
		local timeId = nil
		
		timeId = ktDungeonTimerIds[self.peoName]

		if self.peMatch:GetObjective(timeId) ~= nil and self.peMatch:GetObjective(timeId):GetStatus() == 1 and self.peMatch:GetObjective(timeId):GetMedalPoints() then
			local pts = ktDungeonTimers[self.peoName] - (self.peMatch:GetObjective(timeId):GetElapsedTime() / 1000)
			bonus = pts > 0 and pts or 0
		end
		
		self.nExpectedPoints = self.nPoints + self.debugtotal + bonus
	end
	
	local strVisible	= "ffffffff"
	local strDim		= "66ffffff"
	local strExpected   = "66bbbbbb"
	local strTooltip = ""
	
	-- Bronze - Tier 1
	strTooltip = Apollo.FormatNumber(self.nExpectedPoints, 0, true) .. " / " .. Apollo.FormatNumber(self.nBronze, 0, true)
	self.wndMain:FindChild("Bronze"):SetTooltip(Apollo.FormatNumber(self.nBronze, 0, true))
	self.wndMain:FindChild("Bronze"):SetBGColor(self.nPoints >= self.nBronze and strVisible or strDim)
	self.wndMain:FindChild("Tier1"):FindChild("Active"):Show(self.nPoints < self.nBronze)
	self.wndMain:FindChild("Tier1"):FindChild("ProgressBar"):SetMax(self.nBronze)
	self.wndMain:FindChild("Tier1"):FindChild("ProgressBar"):SetProgress(math.min(self.nBronze, self.nPoints))
	self.wndMain:FindChild("Tier1"):FindChild("ProgressBar"):SetBarColor(self.nPoints >= self.nBronze and strDim or strVisible)
	self.wndMain:FindChild("Tier1"):FindChild("ProgressBarExpected"):SetMax(self.nBronze)
	self.wndMain:FindChild("Tier1"):FindChild("ProgressBarExpected"):SetProgress(math.min(self.nBronze, self.nExpectedPoints))
	self.wndMain:FindChild("Tier1"):FindChild("ProgressBarExpected"):SetBarColor(strExpected)
	self.wndMain:FindChild("Tier1"):FindChild("ProgressBarExpected"):SetTooltip(strTooltip)
	
	-- Silver - Tier 2
	strTooltip = Apollo.FormatNumber(self.nExpectedPoints, 0, true) .. " / " .. Apollo.FormatNumber(self.nSilver, 0, true)
	self.wndMain:FindChild("Silver"):SetTooltip(Apollo.FormatNumber(self.nSilver, 0, true))
	self.wndMain:FindChild("Silver"):SetBGColor(self.nPoints >= self.nSilver and strVisible or strDim)
	self.wndMain:FindChild("Tier2"):FindChild("Active"):Show(self.nPoints >= self.nBronze and self.nPoints < self.nSilver)
	self.wndMain:FindChild("Tier2"):FindChild("ProgressBar"):SetMax(self.nSilver - self.nBronze)
	self.wndMain:FindChild("Tier2"):FindChild("ProgressBar"):SetProgress(self.nPoints > self.nBronze and math.min(self.nSilver, self.nPoints - self.nBronze) or 0)
	self.wndMain:FindChild("Tier2"):FindChild("ProgressBar"):SetBarColor(self.nPoints >= self.nSilver and strDim or strVisible)
	self.wndMain:FindChild("Tier2"):FindChild("ProgressBarExpected"):SetMax(self.nSilver - self.nBronze)
	self.wndMain:FindChild("Tier2"):FindChild("ProgressBarExpected"):SetProgress(self.nExpectedPoints > self.nBronze and math.min(self.nSilver, self.nExpectedPoints - self.nBronze) or 0)
	self.wndMain:FindChild("Tier2"):FindChild("ProgressBarExpected"):SetBarColor(strExpected)
	self.wndMain:FindChild("Tier2"):FindChild("ProgressBarExpected"):SetTooltip(strTooltip)

	-- Gold - Tier 3
	strTooltip = Apollo.FormatNumber(self.nExpectedPoints, 0, true) .. " / " .. Apollo.FormatNumber(self.nGold, 0, true)
	self.wndMain:FindChild("Gold"):SetTooltip(Apollo.FormatNumber(self.nGold, 0, true))
	self.wndMain:FindChild("Gold"):SetBGColor(self.nPoints >= self.nGold and strVisible or strDim)
	self.wndMain:FindChild("Tier3"):FindChild("Active"):Show(self.nPoints >= self.nSilver and self.nPoints < self.nGold)
	self.wndMain:FindChild("Tier3"):FindChild("ProgressBar"):SetMax(self.nGold - self.nSilver)
	self.wndMain:FindChild("Tier3"):FindChild("ProgressBar"):SetProgress(self.nPoints > self.nSilver and math.min(self.nGold, self.nPoints - self.nSilver) or 0)
	self.wndMain:FindChild("Tier3"):FindChild("ProgressBar"):SetBarColor(self.nPoints >= self.nGold and strDim or strVisible)
	self.wndMain:FindChild("Tier3"):FindChild("ProgressBarExpected"):SetMax(self.nGold - self.nSilver)
	self.wndMain:FindChild("Tier3"):FindChild("ProgressBarExpected"):SetProgress(self.nExpectedPoints > self.nSilver and math.min(self.nGold, self.nExpectedPoints - self.nSilver) or 0)
	self.wndMain:FindChild("Tier3"):FindChild("ProgressBarExpected"):SetBarColor(strExpected)
	self.wndMain:FindChild("Tier3"):FindChild("ProgressBarExpected"):SetTooltip(strTooltip)
	
end

function DungeonMedalsEnhanced:OnPointsCleanUpTimer()
	if self.wndPoints == nil then return end
	local nLeft, nTop, nRight, nBottom = self.wndPoints:GetAnchorOffsets()
	local tLoc = WindowLocation.new({ fPoints = { 0.5, 0, 0.5, 0 }, nOffsets = { nLeft-50, nTop-50, nRight-50, nTop-50 }})
	
	self.wndPoints:TransitionMove(tLoc, 1.0)
	self.wndPoints:Show(false, false, 1.0)
	self.nPointDelta = 0
end

function DungeonMedalsEnhanced:OnOneSecTimer()
	if not self.bMatchStarted then
		self:CheckForDungeon()
		return
	end
	
	if not self.peMatch then return end
	
	self.nTimeElapsed = self.peMatch:GetElapsedTime() > 0 and math.ceil(self.peMatch:GetElapsedTime() / 1000) or self.nTimeElapsed
	
	local nTime		= self.nTimeElapsed --+3600 (testing hour formatting)
	local nHours		= math.floor(nTime / 3600)
	local nMinutes	= math.floor((nTime - (nHours * 3600)) / 60)
	local nSeconds 	= nTime - (nHours * 3600) - (nMinutes * 60)
	
	local strTime 		= nHours > 0 
		and string.format("%02d:%02d:%02d", nHours, nMinutes, nSeconds) 
		or string.format("%02d:%02d", nMinutes, nSeconds)
		
	self:UpdatePoints()

	local nPointsForGold = self.peMatch:GetRewardThreshold(PublicEvent.PublicEventRewardTier_Gold) - self.nExpectedPoints
	self.wndMain:FindChild("Time"):SetText(strTime)
	self.wndMain:FindChild("Total"):SetText(Apollo.FormatNumber(self.nPoints, 0, true))
	self.wndMain:FindChild("Needed"):SetText(Apollo.FormatNumber(nPointsForGold, 0, true))
	self.wndMain:Show(self.nTimeElapsed > 0)
end

function DungeonMedalsEnhanced:CheckForDungeon()
	if self.bMatchStarted then
		return true
	end
	
	for key, peCurrent in pairs(PublicEvent.GetActiveEvents()) do
		local eType = peCurrent:GetEventType()
		
		if eType == PublicEvent.PublicEventType_Dungeon then			
			self.peMatch = peCurrent
			
			self.nPoints 	= 0
			self.nBronze 	= self.peMatch:GetRewardThreshold(PublicEvent.PublicEventRewardTier_Bronze)
			self.nSilver 	= self.peMatch:GetRewardThreshold(PublicEvent.PublicEventRewardTier_Silver)	
			self.nGold	 	= self.peMatch:GetRewardThreshold(PublicEvent.PublicEventRewardTier_Gold)
			self.peoName	= peCurrent:GetName()
			
			self.bMatchStarted = self.peoName ~= nil
			
			if self.bMatchStarted then
				self.timerMatchOneSec:Start()
				self:UpdatePoints()
			end
			return true
		end
	end
	return false
end

function DungeonMedalsEnhanced:OnSlashCommand( wndHandler, wndControl, eMouseButton )
	if self.wndDebug:IsShown() then
		self.wndDebug:Show(false)
		Print("DungeonMedalsEnhanced points list hidden, '/dme' to show")
	else
		self.wndDebug:Show(true)
	end
end

local DungeonMedalsEnhancedInstance = DungeonMedalsEnhanced:new()
DungeonMedalsEnhancedInstance:Init()

